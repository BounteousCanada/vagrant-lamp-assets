/*
   +----------------------------------------------------------------------+
   | PHP Version 7                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--with-config-file-path=/opt/phpfarm/inst/php-7.4.8/etc/' '--with-config-file-scan-dir=/opt/phpfarm/inst/php-7.4.8/etc/php.d/' '--disable-short-tags' '--enable-bcmath' '--enable-calendar' '--enable-exif' '--enable-ftp' '--enable-gd' '--enable-intl' '--enable-mbstring' '--enable-opcache' '--enable-pcntl' '--enable-soap' '--enable-sockets' '--enable-wddx' '--with-curl' '--with-freetype-dir=/usr/include/freetype2' '--with-gd' '--with-gettext' '--with-gmp' '--with-jpeg-dir' '--with-layout=GNU' '--with-libzip' '--with-ldap' '--with-mysqli' '--with-openssl' '--with-pear' '--with-pdo-mysql' '--with-png-dir' '--with-readline' '--with-xsl' '--with-zip' '--with-zlib' '--prefix=/opt/phpfarm/inst/php-7.4.8' '--exec-prefix=${prefix}' '--without-pear' '--enable-cgi' '--enable-cli' '--enable-fpm'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/opt/phpfarm/inst/php-7.4.8/lib/php/20190902"
#define PHP_PREFIX              "/opt/phpfarm/inst/php-7.4.8"
#define PHP_BINDIR              "/opt/phpfarm/inst/php-7.4.8/bin"
#define PHP_SBINDIR             "/opt/phpfarm/inst/php-7.4.8/sbin"
#define PHP_MANDIR              "/opt/phpfarm/inst/php-7.4.8/share/man"
#define PHP_LIBDIR              "/opt/phpfarm/inst/php-7.4.8/lib/php"
#define PHP_DATADIR             "/opt/phpfarm/inst/php-7.4.8/share/php"
#define PHP_SYSCONFDIR          "/opt/phpfarm/inst/php-7.4.8/etc"
#define PHP_LOCALSTATEDIR       "/opt/phpfarm/inst/php-7.4.8/var"
#define PHP_CONFIG_FILE_PATH    "/opt/phpfarm/inst/php-7.4.8/etc/"
#define PHP_CONFIG_FILE_SCAN_DIR    "/opt/phpfarm/inst/php-7.4.8/etc/php.d/"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
